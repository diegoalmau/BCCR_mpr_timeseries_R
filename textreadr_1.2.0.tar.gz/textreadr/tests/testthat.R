library("testthat")
library("textreadr")

test_check("textreadr")